import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import static org.junit.Assert.assertEquals;

// tikrinam Laptop & Notebooks TC001

public class Pirmas {
    @Test
    public void Laptops() {
        System.setProperty("webdriver.chrome.driver", "src/main/resources/chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://demo.opencart.com/");
        driver.findElement(By.xpath("//a[normalize-space()='Laptops & Notebooks']")).click();
        // paspaudziam Macs TC002
        driver.findElement(By.xpath("//a[normalize-space()='Macs (0)']")).click();
        assertEquals( "Viskas liuks.", "There are no products to list in this category.", "There are no products to list in this category.");




    }
}
