import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import static org.junit.Assert.assertEquals;
// Tikrinam ar HPL3065 yra parduotuveje

public class Penktas {
    @Test
    public void HPLP3065() {
        System.setProperty("webdriver.chrome.driver", "src/main/resources/chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://demo.opencart.com/");
        driver.findElement(By.xpath("//a[normalize-space()='Laptops & Notebooks']")).click();
        driver.findElement(By.xpath("//a[normalize-space()='Show All Laptops & Notebooks']")).click();
        // pasirenkam HPLP3065, patikrinam ar yra In stock
        driver.findElement(By.xpath("//img[@title='HP LP3065']")).click();
        assertEquals( "Viskas liuks.", "In Stock.", "In Stock.");
    }
}

