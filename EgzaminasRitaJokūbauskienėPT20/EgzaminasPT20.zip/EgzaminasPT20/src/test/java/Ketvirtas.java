import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

//paspaudziam Show all TC009

public class Ketvirtas {
    @Test
    public void ShowAll() {
        System.setProperty("webdriver.chrome.driver", "src/main/resources/chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://demo.opencart.com/");
        driver.findElement(By.xpath("//a[normalize-space()='MP3 Players']")).click();
        driver.findElement(By.xpath("//a[normalize-space()='Show All MP3 Players']")).click();
    }
}