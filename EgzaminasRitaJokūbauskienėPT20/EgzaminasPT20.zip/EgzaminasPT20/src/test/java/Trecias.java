import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

// Tikrinam MP3 Players TC007

public class Trecias {
    @Test
    public void MP3Players() {
        System.setProperty("webdriver.chrome.driver", "src/main/resources/chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://demo.opencart.com/");
        driver.findElement(By.xpath("//a[normalize-space()='MP3 Players']")).click();
        //paspaudziam Test15 TC008
        driver.findElement(By.xpath("//a[normalize-space()='test 15 (0)']")).click();
    }
}